import 'package:flutter/material.dart';

const black = Color(0xFF1A1A1A);
const lightGrey = Color(0xFFEDF0F7);
const grey = Color(0xFF757575);
const blue = Color(0xFF0094FF);
const lightBlue = Color(0xFFB3DFFF);
const yellow = Color(0xFFEFC903);
